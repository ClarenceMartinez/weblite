<div class="modal fade" id="modalxlog" tabindex="-1">
    <div class="modal-dialog modal-xl" >
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title text-center" id="title_vali">Historial</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
            </div>
            <br>
            <div class="modal-body">
                <table class="table table-bordered" id="tblModalHistory">
                    <thead>
                        <tr>
                            <th>Proceso</th>
                            <th>Usuario</th>
                            <th>Fecha Registro</th>
                            <th>Comentario</th>
                            <th>Evidencia</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>

                </table>
            </div>
            <div class="modal-footer">
                <button class="btn-dismis-modal btn btn-success">Ok</button>
            </div>
        </div>
    </div>
</div>